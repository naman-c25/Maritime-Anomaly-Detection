"""Streamlit demo of the vision branch: upload a video, see tracked vessels, zone entries and loitering.

    streamlit run app_streamlit.py
"""
import json
import tempfile
from pathlib import Path

import pandas as pd
import streamlit as st

from mcv.config import ROOT, load_cameras, load_config
from mcv.pipeline import process_video

st.set_page_config(page_title="Vessel vision branch", layout="wide")
cfg = load_config()
cams = load_cameras(cfg["rules"]["cameras_file"])
weights_found = sorted(str(p) for p in (ROOT / "models").glob("*.pt")) if (ROOT / "models").exists() else []

st.title("Computer-vision anomaly detection")
with st.sidebar:
    weights = st.selectbox("Detector weights", weights_found) if weights_found else st.text_input("Detector weights path")
    camera = st.selectbox("Camera", list(cams))
    tracker = st.selectbox("Tracker", ["bytetrack", "deepsort", "none"])
    cfg["rules"]["dwell_seconds"] = st.number_input("Dwell limit T_dwell (s)", 5, 3600, int(cfg["rules"]["dwell_seconds"]))
    cfg["inference"]["conf"] = st.slider("Confidence cut-off", 0.05, 0.9, float(cfg["inference"]["conf"]), 0.05)
    cfg["inference"]["frame_stride"] = st.number_input("Process every n-th frame", 1, 30, int(cfg["inference"]["frame_stride"]))

video = st.file_uploader("Upload a harbour / UAV video", type=["mp4", "avi", "mov", "mkv"])
if video and weights and st.button("Run detection and tracking"):
    work = Path(tempfile.mkdtemp())
    src = work / video.name
    src.write_bytes(video.read())
    with st.spinner("Processing video..."):
        summary = process_video(src, cfg, cams[camera], weights, work / "out", tracker=tracker)
    tracks = pd.DataFrame(summary["tracks"])
    flagged = tracks[tracks["s_vision"] > 0] if len(tracks) else tracks
    c1, c2, c3 = st.columns(3)
    c1.metric("Tracked vessels", len(tracks))
    c2.metric("Flagged vessels", len(flagged))
    c3.metric("Events", len(summary["events"]))
    annotated = work / "out" / "annotated.mp4"
    if annotated.exists():
        st.video(annotated.read_bytes())
        st.caption("If the video does not play in the browser, download it below (mp4v codec).")
        st.download_button("Download annotated video", annotated.read_bytes(), "annotated.mp4")
    st.subheader("Alerts")
    st.dataframe(flagged[["track_id", "s_vision", "reasons", "first_t", "last_t"]] if len(flagged) else flagged,
                 use_container_width=True)
    st.subheader("All tracks")
    st.dataframe(tracks, use_container_width=True)
    st.download_button("Download summary.json", json.dumps(summary, indent=2), "summary.json")
