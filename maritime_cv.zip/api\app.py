"""FastAPI service for the vision branch and the fusion layer (Sect. 3.4).

    set MCV_WEIGHTS=models/vessel_yolov8s_best.pt
    set MCV_AIS_VAL_ERRORS=path/to/validation_errors.npy     (reconstruction errors of the AIS validation windows)
    uvicorn api.app:app --reload --port 8001

Endpoints
    POST /api/v1/predict-vision   multipart: file (image or video), camera (key in cameras JSON), start_time (optional)
    POST /api/v1/fuse             JSON: {"vision_tracks": [...], "ais_points": [...]}
Your AIS service keeps /api/v1/predict-ais; run both apps, or mount this router into the AIS app.
"""
import os
import sys
import tempfile
from pathlib import Path

import cv2
import numpy as np
from fastapi import APIRouter, FastAPI, File, Form, HTTPException, UploadFile
from pydantic import BaseModel

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from mcv.config import ROOT, load_cameras, load_config  # noqa: E402
from mcv.fusion import AisScorer, build_alerts  # noqa: E402
from mcv.pipeline import process_image, process_video  # noqa: E402

CFG = load_config(os.environ.get("MCV_CONFIG"))
CAMERAS = load_cameras(CFG["rules"]["cameras_file"])
WEIGHTS = os.environ.get("MCV_WEIGHTS", str(ROOT / "models" / "vessel_yolov8s_best.pt"))
VIDEO_EXT = {".mp4", ".avi", ".mov", ".mkv"}

_model = None
_scorer = None


def model():
    global _model
    if _model is None:
        from ultralytics import YOLO
        if not Path(WEIGHTS).exists():
            raise HTTPException(500, f"weights not found: {WEIGHTS} (set MCV_WEIGHTS)")
        _model = YOLO(WEIGHTS)
    return _model


def scorer():
    global _scorer
    if _scorer is None:
        path = os.environ.get("MCV_AIS_VAL_ERRORS")
        if not path or not Path(path).exists():
            raise HTTPException(500, "set MCV_AIS_VAL_ERRORS to a .npy file with the AIS validation reconstruction errors")
        _scorer = AisScorer(np.load(path))
    return _scorer


router = APIRouter(prefix="/api/v1")


@router.post("/predict-vision")
async def predict_vision(file: UploadFile = File(...), camera: str = Form(...), start_time: float = Form(0.0)):
    if camera not in CAMERAS:
        raise HTTPException(400, f"unknown camera '{camera}'; known: {list(CAMERAS)}")
    data = await file.read()
    suffix = Path(file.filename or "").suffix.lower()
    if suffix in VIDEO_EXT:
        with tempfile.TemporaryDirectory() as tmp:
            src = Path(tmp) / f"input{suffix}"
            src.write_bytes(data)
            summary = process_video(src, CFG, CAMERAS[camera], WEIGHTS, Path(tmp) / "out", write_video=False,
                                    start_time=start_time)
        summary.pop("video", None)
        return summary
    img = cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_COLOR)
    if img is None:
        raise HTTPException(400, "could not decode the uploaded file as an image or video")
    return process_image(img, CFG, CAMERAS[camera], model())


class FuseRequest(BaseModel):
    vision_tracks: list[dict]
    ais_points: list[dict]


@router.post("/fuse")
def fuse(req: FuseRequest):
    return {"alerts": build_alerts(req.vision_tracks, req.ais_points, scorer(), CFG)}


@router.get("/health")
def health():
    return {"weights": WEIGHTS, "weights_found": Path(WEIGHTS).exists(), "cameras": list(CAMERAS)}


app = FastAPI(title="Maritime vision and fusion service")
app.include_router(router)
