"""End-to-end vision branch: frames → ROI/CLAHE → YOLOv8 + tracker → zone/dwell rules → events and s_vision."""
import json
from pathlib import Path

import cv2

from .geo import CameraProjection
from .preprocess import apply_roi, maybe_clahe
from .rules import TrackRules
from .scoring import summarise_tracks
from .tracking import VesselTracker

COLORS = {"normal": (60, 200, 60), "zone": (40, 40, 230), "loiter": (200, 60, 200)}


def _draw(frame, box, label, color):
    x1, y1, x2, y2 = map(int, box.xyxy)
    cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
    cv2.putText(frame, label, (x1, max(15, y1 - 6)), cv2.FONT_HERSHEY_SIMPLEX, 0.55, color, 2, cv2.LINE_AA)


def _draw_zones(frame, cam):
    import numpy as np
    for z in cam.get("restricted_zones", []):
        cv2.polylines(frame, [np.asarray(z["polygon"], np.int32)], True, COLORS["zone"], 2)


def process_video(video_path, cfg, cam, weights, out_dir, tracker=None, use_clahe=None, use_dwell=True,
                  write_video=True, start_time=0.0):
    """Runs the vision branch on one video. `start_time` (Unix seconds) aligns frame times with AIS timestamps."""
    inf, rules_cfg = cfg["inference"], cfg["rules"]
    tracker = tracker or cfg["tracking"]["tracker"]
    out_dir = Path(out_dir); out_dir.mkdir(parents=True, exist_ok=True)

    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        raise IOError(f"cannot open video {video_path}")
    fps = cap.get(cv2.CAP_PROP_FPS) or 25.0
    w, h = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)), int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    stride = max(1, int(inf.get("frame_stride", 1)))

    vt = VesselTracker(weights, tracker, inf["conf"], inf["iou"], cfg["model"]["imgsz"], inf["device"],
                       cfg["tracking"].get("deepsort_max_age", 30))
    rules = TrackRules(cam.get("restricted_zones", []), rules_cfg["dwell_seconds"], rules_cfg["loiter_radius_px"], use_dwell)
    proj = CameraProjection.from_camera(cam)
    writer = None
    if write_video:
        writer = cv2.VideoWriter(str(out_dir / "annotated.mp4"), cv2.VideoWriter_fourcc(*"mp4v"), fps / stride, (w, h))

    events, mot_lines, idx, clahe_frames = [], [], 0, 0
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        if idx % stride:
            idx += 1
            continue
        t = start_time + idx / fps
        work = apply_roi(frame, cam.get("roi"))
        work, applied = maybe_clahe(work, inf["clahe"], force=use_clahe)   # None = auto (low-light only)
        clahe_frames += applied

        for box in vt.update(work):
            x1, y1, x2, y2 = box.xyxy
            ground = ((x1 + x2) / 2.0, y2)                     # waterline point of the hull
            new = rules.update(box.track_id, ground, t, box.conf)
            for e in new:
                e["frame"] = idx
                if proj:
                    e["lat"], e["lon"] = map(lambda v: round(v, 6), proj.pixel_to_latlon(ground))
            events += new
            mot_lines.append(f"{idx + 1},{box.track_id},{x1:.1f},{y1:.1f},{x2 - x1:.1f},{y2 - y1:.1f},{box.conf:.3f},-1,-1,-1")
            if writer is not None:
                st = rules.tracks[box.track_id]
                kind = "zone" if st.zones_inside else ("loiter" if st.loitering else "normal")
                _draw(frame, box, f"ID {box.track_id} {box.conf:.2f}", COLORS[kind])
        if writer is not None:
            _draw_zones(frame, cam)
            writer.write(frame)
        idx += 1

    cap.release()
    if writer is not None:
        writer.release()
    (out_dir / "tracks_mot.txt").write_text("\n".join(mot_lines) + "\n", encoding="utf-8")
    summary = {"video": str(video_path), "fps": fps, "frames": idx, "frame_stride": stride, "tracker": tracker,
               "clahe_frames": int(clahe_frames), "events": events,
               "tracks": summarise_tracks(rules, proj.pixel_to_latlon if proj else None)}
    for tr in summary["tracks"]:
        tr["last_t"] = round(tr["last_t"], 2)
    (out_dir / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    return summary


def process_image(image_bgr, cfg, cam, model):
    """Single-image detection with zone flags (no tracking or dwell time)."""
    from .rules import point_in_polygon
    inf = cfg["inference"]
    work, applied = maybe_clahe(apply_roi(image_bgr, cam.get("roi") if cam else None), inf["clahe"])
    r = model.predict(work, conf=inf["conf"], iou=inf["iou"], imgsz=cfg["model"]["imgsz"], device=inf["device"],
                      verbose=False)[0]
    zones = cam.get("restricted_zones", []) if cam else []
    dets = []
    for (x1, y1, x2, y2), c in zip(r.boxes.xyxy.tolist(), r.boxes.conf.tolist()):
        ground = ((x1 + x2) / 2.0, y2)
        inside = [z["name"] for z in zones if point_in_polygon(ground, z["polygon"])]
        dets.append({"box": [round(v, 1) for v in (x1, y1, x2, y2)], "conf": round(c, 4), "zones": inside,
                     "s_vision": round(c, 4) if inside else 0.0})
    return {"clahe": applied, "detections": dets}
