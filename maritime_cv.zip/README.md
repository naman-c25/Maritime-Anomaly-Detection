# Maritime vessel anomaly detection: computer-vision branch

Implements Sects. 3.3–3.4 of the paper: YOLOv8 vessel detection, ByteTrack/DeepSORT tracking, restricted-zone and
loitering rules, the vision score `s_vision`, and the AIS/vision fusion layer with the FastAPI endpoints. Each script
produces the numbers for one table of Sect. 5.

```
configs/default.yaml          all settings (Table 2, fusion α, gates, alert levels)
configs/cameras_example.json  per-camera ROI, restricted zones and ground control points
mcv/                          library: data, preprocess, detector, tracking, rules, scoring, geo, fusion, metrics, pipeline
scripts/                      prepare_data, train, evaluate_detector, train_baselines, run_video,
                              eval_tracking, eval_fusion, ablation
api/app.py                    FastAPI: /api/v1/predict-vision, /api/v1/fuse, /api/v1/health
app_streamlit.py              demo page for the vision branch
notebooks/train_on_colab.ipynb  GPU training on Colab
tests/test_logic.py           unit tests for rules, projection and fusion
```

## 1. Install
```
python -m venv .venv
.venv\Scripts\activate            (Linux/Colab: source .venv/bin/activate)
pip install -r requirements.txt
```
Training needs a GPU. Use `notebooks/train_on_colab.ipynb` (free T4) and run inference/the API on your PC.

## 2. Data (Roboflow)
Edit `configs/default.yaml` → `data.roboflow` (workspace, project, version) and `data.vessel_classes`
(the class names that count as vessels; others such as buoys or birds are dropped). Then:
```
set ROBOFLOW_API_KEY=your_key
python scripts/prepare_data.py --download
```
This converts labels to one `vessel` class (originals kept in `labels_original/`), adds darkened and hazy copies of
20% of the training images, and writes `test_day.txt`, `test_night.txt`, `test_fog.txt`. The condition split is
guessed from brightness and haze; pass `--conditions-csv file.csv` (filename,condition) to use your own tags.

## 3. Train and evaluate the detector (Table 8)
```
python scripts/train.py --data data/maritime/data_vessel.yaml --weights yolov8s.pt
python scripts/evaluate_detector.py --weights models/vessel_yolov8s_best.pt --data data/maritime/data_vessel.yaml --device 0
python scripts/train_baselines.py --data data/maritime/data_vessel.yaml --model fasterrcnn
python scripts/train_baselines.py --data data/maritime/data_vessel.yaml --model ssd
```
Results go to `results/*.json`. Measure FPS on the device you report in the paper.

## 4. Cameras, zones and video
For each camera, copy the example entry in `configs/cameras_example.json` and fill in:
- `roi`: polygon (pixels) of the water area to keep;
- `restricted_zones`: named polygons (pixels) on the water;
- `gcp`: at least 4 points visible on the water/quay with their pixel position and real lat/lon (needed for fusion).
```
python scripts/run_video.py --video clip.mp4 --weights models/vessel_yolov8s_best.pt --camera harbour_cam_1 --start-time 1714000000
```
Output: `outputs/<clip>/annotated.mp4`, `tracks_mot.txt`, `summary.json` (tracks, events, `s_vision`, lat/lon).

## 5. Tracking and rule evaluation (Table 9, event P/R)
Annotate test clips in CVAT (export "MOT 1.1" → save as `<clip>_gt.txt`) and list events in `<clip>_events.csv`
(`type,start_s,end_s`, type = zone_entry or loitering). List the clips in `clips.json`:
`[{"video": "clips/cam1_a.mp4", "camera": "harbour_cam_1"}]`
```
python scripts/eval_tracking.py --clips clips.json --weights models/vessel_yolov8s_best.pt
python scripts/ablation.py --weights models/vessel_yolov8s_best.pt --data data/maritime/data_vessel.yaml --clips clips.json
```

## 6. Fusion with the AIS branch (Table 10)
The AIS branch provides, per scored window: `mmsi, t (Unix s), lat, lon, recon_error`, plus the array of validation
reconstruction errors saved as `validation_errors.npy` (used to turn an error into `s_AIS` by percentile rank).
Build `episodes.csv` (`episode_id,label,s_ais,s_vision`) for labelled episodes, then:
```
python scripts/eval_fusion.py --episodes episodes.csv --days 14
```
It sweeps α, reports AIS-only / vision-only / fused P, R, F1 and false alerts per day, and calibrates the alert levels.

## 7. Service and demo
```
set MCV_WEIGHTS=models\vessel_yolov8s_best.pt
set MCV_AIS_VAL_ERRORS=path\to\validation_errors.npy
uvicorn api.app:app --port 8001
streamlit run app_streamlit.py
```

## Tests
```
pytest -q
```
