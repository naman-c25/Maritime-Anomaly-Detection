"""Multi-object tracking (Sect. 3.3.3): ByteTrack via Ultralytics, DeepSORT via deep-sort-realtime, or none."""
from dataclasses import dataclass
from itertools import count


@dataclass
class TrackedBox:
    track_id: int
    xyxy: tuple
    conf: float


class VesselTracker:
    def __init__(self, weights, tracker="bytetrack", conf=0.25, iou=0.45, imgsz=640, device="cpu", deepsort_max_age=30):
        from ultralytics import YOLO
        self.model = YOLO(str(weights))
        self.kind = tracker
        self.kw = dict(conf=conf, iou=iou, imgsz=imgsz, device=device, verbose=False)
        self._ids = count(1)
        if tracker == "deepsort":
            from deep_sort_realtime.deepsort_tracker import DeepSort
            self.ds = DeepSort(max_age=deepsort_max_age)
        elif tracker not in ("bytetrack", "none"):
            raise ValueError(f"unknown tracker: {tracker}")

    def update(self, frame):
        if self.kind == "bytetrack":
            r = self.model.track(frame, persist=True, tracker="bytetrack.yaml", **self.kw)[0]
            if r.boxes is None or r.boxes.id is None:
                return []
            return [TrackedBox(int(i), tuple(map(float, b)), float(c))
                    for b, i, c in zip(r.boxes.xyxy.tolist(), r.boxes.id.tolist(), r.boxes.conf.tolist())]

        r = self.model.predict(frame, **self.kw)[0]
        boxes = list(zip(r.boxes.xyxy.tolist(), r.boxes.conf.tolist()))
        if self.kind == "none":   # ablation: every detection gets a fresh identity, so nothing persists
            return [TrackedBox(next(self._ids), tuple(map(float, b)), float(c)) for b, c in boxes]

        dets = [([x1, y1, x2 - x1, y2 - y1], c, "vessel") for (x1, y1, x2, y2), c in boxes]
        out = []
        for t in self.ds.update_tracks(dets, frame=frame):
            if not t.is_confirmed() or t.time_since_update > 0:
                continue
            conf = t.get_det_conf()
            out.append(TrackedBox(int(t.track_id), tuple(map(float, t.to_ltrb())), float(conf if conf is not None else 0.0)))
        return out
